//
//  menu.hpp
//  project1
//
//  Created by Xavier on 1/15/18.
//  Copyright © 2018 Xavier. All rights reserved.
//

#ifndef menu_hpp
#define menu_hpp

#include <stdio.h>

int startMenu ();

void getValues(int*, int*, int*, int*, int*);

bool playAgain(bool);
#endif /* menu_hpp */
