//  This is the header file for the menu function.
//  Created by Xavier on 2/21/18.
//  Copyright © 2018 Xavier. All rights reserved.
//

#ifndef menu_hpp
#define menu_hpp

#include <stdio.h>


//  Function prototypes
void titleDisplay();
void menuDisplay();


#endif /* menu_hpp */
