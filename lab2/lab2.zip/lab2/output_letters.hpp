//  This is the header file for the output_letters function file.
//  Created by Xavier on 1/16/18.
//  Copyright © 2018 Xavier. All rights reserved.
//

#ifndef output_letters_hpp
#define output_letters_hpp
#include <iostream>
#include <string>
#include <fstream>
#include <stdio.h>
using namespace std;

void output_letters(ofstream& , int*);

#endif /* output_letters_hpp */
