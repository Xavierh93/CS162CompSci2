//  This is the header file for the count_letters function.
//  Created by Xavier on 1/16/18.
//  Copyright © 2018 Xavier. All rights reserved.
//

#ifndef count_letters_hpp
#define count_letters_hpp
#include <iostream>
#include <fstream>
#include <string>
#include <stdio.h>
using namespace std;

void count_letters(ifstream &, int *);

#endif /* count_letters_hpp */
