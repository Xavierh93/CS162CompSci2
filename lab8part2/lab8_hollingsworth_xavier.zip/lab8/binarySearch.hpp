//  This is the header file for the binarySearch function.
//  Created by Xavier on 2/27/18.
//  Copyright © 2018 Xavier. All rights reserved.

#ifndef binarySearch_hpp
#define binarySearch_hpp

#include <stdio.h>
#include <string>
#include <fstream>
using namespace std;


void binarySearch(ifstream &iFile, int value, int size, string fileName);


#endif /* binarySearch_hpp */
