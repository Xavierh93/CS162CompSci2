//  This is the header file for the readFile function
//  Created by Xavier on 2/27/18.
//  Copyright © 2018 Xavier. All rights reserved.

#ifndef readFile_hpp
#define readFile_hpp

#include <stdio.h>
#include <fstream>
using namespace std;

void readFile(ifstream &iFile, int array[], int size);

#endif /* readFile_hpp */
