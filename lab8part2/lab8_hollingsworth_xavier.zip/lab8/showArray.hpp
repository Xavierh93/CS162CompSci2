//  This is the header file for the showArray function
//  Created by Xavier on 2/27/18.
//  Copyright © 2018 Xavier. All rights reserved.

#ifndef showArray_hpp
#define showArray_hpp

#include <stdio.h>

void showArray(int array[], int size);

#endif /* showArray_hpp */
