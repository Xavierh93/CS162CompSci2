//  This is the header file for the displayFile function
//  Created by Xavier on 2/27/18.
//  Copyright © 2018 Xavier. All rights reserved.

#ifndef displayFile_hpp
#define displayFile_hpp

#include <stdio.h>
#include <fstream>
#include <string>
using namespace std;

void displayFile(ifstream &iFile, string fileName);


#endif /* displayFile_hpp */
