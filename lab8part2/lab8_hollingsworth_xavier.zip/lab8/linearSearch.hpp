//  This is the header file for the Linear Search function
//  Created by Xavier on 2/27/18.
//  Copyright © 2018 Xavier. All rights reserved.

#ifndef linearSearch_hpp
#define linearSearch_hpp

#include <stdio.h>
#include <iostream>
#include <string>
#include <fstream>
using namespace std;


void linearSearch(string fileName, int array[], int size, int target);

#endif /* linearSearch_hpp */
