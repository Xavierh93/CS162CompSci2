//  This is the header file for the copyArray function
//  Created by Xavier on 2/27/18.
//  Copyright © 2018 Xavier. All rights reserved.

#ifndef copyArray_hpp
#define copyArray_hpp

#include <stdio.h>
#include <fstream>
using namespace std;


void copyArray(ofstream &oFile, int array[], int size);

#endif /* copyArray_hpp */
