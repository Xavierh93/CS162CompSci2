//  This is the header file for the queue function file.
//  Created by Xavier on 3/9/18.
//  Copyright © 2018 Xavier. All rights reserved.
//

#ifndef queue_hpp
#define queue_hpp

#include <stdio.h>

void queueContainer();

#endif /* queue_hpp */
