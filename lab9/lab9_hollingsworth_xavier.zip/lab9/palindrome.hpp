//  This is the header file for the palindrome function file.
//  Created by Xavier on 3/9/18.
//  Copyright © 2018 Xavier. All rights reserved.
//

#ifndef palindrome_hpp
#define palindrome_hpp

#include <stdio.h>

void palindrome();
void reverse(char *pali, int length);

#endif /* palindrome_hpp */
