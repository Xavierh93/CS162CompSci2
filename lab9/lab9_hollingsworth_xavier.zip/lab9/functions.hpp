//  This is the header file for the functions file.
//  Created by Xavier on 3/9/18.
//  Copyright © 2018 Xavier. All rights reserved.
//

#ifndef functions_hpp
#define functions_hpp

#include <stdio.h>


void titleDisplay();
void mainMenu();
int mainMenuRounds();
double mainMenuPush();
double mainMenuPop();



#endif /* functions_hpp */
