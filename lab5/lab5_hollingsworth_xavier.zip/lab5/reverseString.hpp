//  This is the header file for the reverseString function.
//  Created by Xavier Elon Hollingsworth on 2/7/18.
//  Copyright © 2018 Xavier Elon Hollingsworth. All rights reserved.
//

#ifndef reverseString_hpp
#define reverseString_hpp

#include <stdio.h>
#include <string>
using namespace std;

void reverseString(const string &str);

#endif /* reverseString_hpp */
