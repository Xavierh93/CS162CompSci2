//  This is the header file for the triangularNumber function.
//  Created by Xavier Elon Hollingsworth on 2/7/18.
//  Copyright © 2018 Xavier Elon Hollingsworth. All rights reserved.
//

#ifndef triangularNumber_hpp
#define triangularNumber_hpp

#include <stdio.h>

int triangularNumber(int);

#endif /* triangularNumber_hpp */
