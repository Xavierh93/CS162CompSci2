//  This is the header file for the sumOfArray function.
//  Created by Xavier Elon Hollingsworth on 2/7/18.
//  Copyright © 2018 Xavier Elon Hollingsworth. All rights reserved.

#ifndef sumOfArray_hpp
#define sumOfArray_hpp

#include <stdio.h>

int sumOfArray(int *array, int size);



#endif /* sumOfArray_hpp */
